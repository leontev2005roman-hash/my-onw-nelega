const http = require("http");
const WebSocket = require("ws");
const fs = require("fs");
const path = require("path");

const COLORS = ["#e8a87c","#85c1e9","#a29bfe","#55efc4","#fd79a8","#fdcb6e","#6c5ce7","#00b894","#e17055","#74b9ff"];

const USERS_FILE = path.join(__dirname, "users.json");
const DM_FILE    = path.join(__dirname, "dm.json");

function loadJSON(file, def) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return def; }
}
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// USERS: { name: { password, color, friends: [] } }
let USERS    = loadJSON(USERS_FILE, {});
let DM_STORE = loadJSON(DM_FILE, {});

// migrate old users without friends field
for (const u of Object.values(USERS)) {
  if (!u.friends) u.friends = [];
}

const server = http.createServer((req, res) => {
  let filePath = req.url === "/" ? "/index.html" : req.url;
  filePath = path.join(__dirname, "public", filePath);
  const ext = path.extname(filePath);
  const mime = { ".html": "text/html", ".js": "application/javascript", ".css": "text/css" };
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end("Not found"); return; }
    res.writeHead(200, { "Content-Type": mime[ext] || "text/plain" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });

let publicMessages = [];
const clients = new Map(); // ws -> name

function dmKey(a, b) { return [a, b].sort().join("|"); }

function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => { if (ws.readyState === WebSocket.OPEN) ws.send(msg); });
}
function sendTo(name, data) {
  const msg = JSON.stringify(data);
  clients.forEach((n, ws) => { if (n === name && ws.readyState === WebSocket.OPEN) ws.send(msg); });
}
function getOnlineUsers() { return [...new Set(clients.values())]; }
function pickColor(name) {
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffff;
  return COLORS[h % COLORS.length];
}
function now() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
}
function getUserColors() {
  const map = {};
  for (const [n, u] of Object.entries(USERS)) map[n] = u.color;
  return map;
}

wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    let data;
    try { data = JSON.parse(raw); } catch { return; }

    // ── REGISTER ──
    if (data.type === "register") {
      const name = (data.name || "").trim();
      const pass = (data.password || "").trim();
      if (!name || name.length < 2 || name.length > 20)
        return ws.send(JSON.stringify({ type: "reg_fail", text: "Имя: от 2 до 20 символов" }));
      if (!pass || pass.length < 4)
        return ws.send(JSON.stringify({ type: "reg_fail", text: "Пароль: минимум 4 символа" }));
      if (USERS[name])
        return ws.send(JSON.stringify({ type: "reg_fail", text: "Это имя уже занято" }));
      USERS[name] = { password: pass, color: pickColor(name), friends: [] };
      saveJSON(USERS_FILE, USERS);
      authSuccess(ws, name, true);
      return;
    }

    // ── LOGIN ──
    if (data.type === "login") {
      const name = (data.name || "").trim();
      const pass = data.password || "";
      const user = USERS[name];
      if (user && user.password === pass) authSuccess(ws, name, false);
      else ws.send(JSON.stringify({ type: "auth_fail", text: "Неверное имя или пароль" }));
      return;
    }

    if (!ws.name) return;
    const me = USERS[ws.name];

    // ── ADD FRIEND ──
    if (data.type === "add_friend") {
      const target = (data.name || "").trim();
      if (!USERS[target]) return ws.send(JSON.stringify({ type: "friend_err", text: "Пользователь не найден" }));
      if (target === ws.name) return ws.send(JSON.stringify({ type: "friend_err", text: "Нельзя добавить себя" }));
      if (!me.friends.includes(target)) {
        me.friends.push(target);
        saveJSON(USERS_FILE, USERS);
      }
      ws.send(JSON.stringify({ type: "friends_update", friends: me.friends }));
      return;
    }

    // ── REMOVE FRIEND ──
    if (data.type === "remove_friend") {
      const target = (data.name || "").trim();
      me.friends = me.friends.filter(f => f !== target);
      saveJSON(USERS_FILE, USERS);
      ws.send(JSON.stringify({ type: "friends_update", friends: me.friends }));
      return;
    }

    // ── PUBLIC MESSAGE ──
    if (data.type === "message") {
      const msg = { id: Date.now(), name: ws.name, color: ws.color, text: data.text.slice(0,1000), time: now() };
      publicMessages.push(msg);
      if (publicMessages.length > 300) publicMessages = publicMessages.slice(-300);
      broadcast({ type: "message", ...msg });
      return;
    }

    // ── DIRECT MESSAGE ──
    if (data.type === "dm") {
      const { to, text } = data;
      if (!USERS[to] || !text) return;
      const key = dmKey(ws.name, to);
      const msg = { id: Date.now(), from: ws.name, text: text.slice(0,1000), time: now() };
      if (!DM_STORE[key]) DM_STORE[key] = [];
      DM_STORE[key].push(msg);
      if (DM_STORE[key].length > 300) DM_STORE[key] = DM_STORE[key].slice(-300);
      saveJSON(DM_FILE, DM_STORE);
      const packet = { type: "dm", from: ws.name, fromColor: ws.color, to, ...msg };
      sendTo(ws.name, packet);
      sendTo(to, packet);
      return;
    }

    // ── LOAD DM HISTORY ──
    if (data.type === "load_dm") {
      const key = dmKey(ws.name, data.with);
      ws.send(JSON.stringify({ type: "dm_history", with: data.with, messages: DM_STORE[key] || [] }));
      return;
    }
  });

  ws.on("close", () => {
    if (ws.name) {
      clients.delete(ws);
      broadcast({ type: "online", users: getOnlineUsers(), colors: getUserColors() });
      broadcast({ type: "system", text: `${ws.name} вышел из чата`, time: now() });
    }
  });
});

function authSuccess(ws, name, isNew) {
  const user = USERS[name];
  clients.set(ws, name);
  ws.name = name; ws.color = user.color;
  ws.send(JSON.stringify({
    type: "auth_ok", name, color: user.color,
    friends: user.friends || [],
    allUsers: Object.keys(USERS),
    colors: getUserColors(),
  }));
  ws.send(JSON.stringify({ type: "history", messages: publicMessages }));
  broadcast({ type: "online", users: getOnlineUsers(), colors: getUserColors() });
  broadcast({ type: "system", text: isNew ? `${name} присоединился к чату` : `${name} вошёл в чат`, time: now() });
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Сервер: http://localhost:${PORT}`));
